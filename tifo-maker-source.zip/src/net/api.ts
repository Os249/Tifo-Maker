import type { DesignStore } from '../core/design';
import type { SeatMap, StadiumTemplate } from '../core/types';
import type { TifoSpec } from '../core/tifoSpec';

/**
 * Browser client for the Tifo Maker API. Cells gzip client-side with
 * CompressionStream (a 60k design is ~300 B on the wire); thumbnails are
 * rendered client-side on save, exactly as the blueprint planned — the server
 * never rasterizes anything.
 *
 * The bearer token lives in module memory: a page refresh signs you out.
 * Swapping in persistent storage is a product decision for later.
 */

const API = '/api';
const TOKEN_KEY = 'tifo_token_v1';

export interface CommunityStadium {
  id: string;
  name: string;
  country: string | null;
  template: StadiumTemplate;
}

/** Fetch approved community stadium templates (best-effort; [] on any failure). */
export async function fetchCommunityStadiums(): Promise<CommunityStadium[]> {
  try {
    const res = await fetch(`${API}/stadiums/community`);
    if (!res.ok) return [];
    const data = (await res.json().catch(() => null)) as { stadiums?: CommunityStadium[] } | null;
    return Array.isArray(data?.stadiums) ? (data as { stadiums: CommunityStadium[] }).stadiums : [];
  } catch {
    return [];
  }
}

/** Submit a stadium template to the community for review. Returns its id, or null. */
export async function submitStadium(template: StadiumTemplate, name: string, country?: string): Promise<{ id: string } | null> {
  try {
    const res = await fetch(`${API}/stadiums`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ template, name, ...(country ? { country } : {}) }),
    });
    if (!res.ok) return null;
    return (await res.json().catch(() => null)) as { id: string } | null;
  } catch {
    return null;
  }
}

export interface PendingStadium {
  id: string;
  name: string;
  country: string | null;
  template: StadiumTemplate;
  status: string;
  createdAt: string;
}

/** Admin: pending community submissions. Returns [] for non-admins (403) or errors. */
export async function fetchPendingStadiums(): Promise<PendingStadium[]> {
  try {
    const res = await fetch(`${API}/stadiums/pending`, { headers: authHeaders(false) });
    if (!res.ok) return [];
    const data = (await res.json().catch(() => null)) as { stadiums?: PendingStadium[] } | null;
    return Array.isArray(data?.stadiums) ? (data as { stadiums: PendingStadium[] }).stadiums : [];
  } catch {
    return [];
  }
}

/** Admin: approve or reject a submission. Returns whether it succeeded. */
export async function reviewStadium(id: string, approve: boolean): Promise<boolean> {
  try {
    const res = await fetch(`${API}/stadiums/${encodeURIComponent(id)}/review`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ approve }),
    });
    return res.ok;
  } catch {
    return false;
  }
}
// Restore a persisted session on load so auth survives navigation between the
// editor, the community page, and share links (all separate page loads).
let token: string | null = (() => {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
})();

function setToken(t: string | null): void {
  token = t;
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage unavailable — session stays in-memory for this page */
  }
}

export const isSignedIn = (): boolean => token !== null;

/** Sign out: clear the persisted session. */
export function signOut(): void {
  setToken(null);
}

function authHeaders(json: boolean): Record<string, string> {
  const h: Record<string, string> = {};
  if (json) h['content-type'] = 'application/json';
  if (token) h.authorization = `Bearer ${token}`;
  return h;
}

async function expectOk(res: Response): Promise<unknown> {
  if (!res.ok) {
    const body = (await res.json().catch(() => null)) as { error?: string } | null;
    throw new Error(body?.error ?? `${res.status} ${res.statusText}`);
  }
  return res.status === 204 ? null : res.json();
}

// ---------- auth ----------

export async function login(username: string, password: string): Promise<string> {
  const data = (await expectOk(
    await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username, password }),
    }),
  )) as { token: string; username: string };
  setToken(data.token);
  return data.username;
}

export async function register(
  username: string,
  password: string,
  email: string,
  acceptedVersion: string,
): Promise<string> {
  const data = (await expectOk(
    await fetch(`${API}/auth/register`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ username, password, email, acceptedVersion }),
    }),
  )) as { token: string; username: string };
  setToken(data.token);
  return data.username;
}

/** Attach or change the signed-in user's email (resets verification). */
export async function setAccountEmail(email: string, acceptedVersion?: string): Promise<void> {
  await expectOk(
    await fetch(`${API}/account/email`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ email, acceptedVersion }),
    }),
  );
}

/** Ask the server to re-send the email-verification link to the signed-in user. */
export async function resendVerification(): Promise<void> {
  await expectOk(await fetch(`${API}/auth/verify/resend`, { method: 'POST', headers: authHeaders(true) }));
}

/** Change the signed-in user's password (requires the current one). */
export async function changePassword(currentPassword: string, newPassword: string): Promise<void> {
  await expectOk(
    await fetch(`${API}/account/password`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ currentPassword, newPassword }),
    }),
  );
}

/** Request a password-reset email. Always resolves (no account enumeration). */
export async function requestPasswordReset(email: string): Promise<void> {
  await expectOk(
    await fetch(`${API}/auth/forgot`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ email }),
    }),
  );
}

/** Complete a password reset using the emailed token. */
export async function resetPassword(token: string, newPassword: string): Promise<void> {
  await expectOk(
    await fetch(`${API}/auth/reset`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ token, newPassword }),
    }),
  );
}

/** Download the signed-in user's data (PDPL/GDPR access right). */
export async function exportMyData(): Promise<unknown> {
  return await expectOk(await fetch(`${API}/account/export`, { headers: authHeaders(false) }));
}

/** Permanently delete the signed-in user's account + designs, then sign out. */
export async function deleteAccount(): Promise<void> {
  const res = await fetch(`${API}/account`, { method: 'DELETE', headers: authHeaders(false) });
  if (!res.ok && res.status !== 204) throw new Error('could not delete account');
  signOut();
}

// ---------- codecs ----------

async function gzip(data: Uint8Array): Promise<Uint8Array> {
  const stream = new Blob([data.buffer as ArrayBuffer]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function gunzip(data: Uint8Array): Promise<Uint8Array> {
  const stream = new Blob([data.buffer as ArrayBuffer]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

function toB64(bytes: Uint8Array): string {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(s);
}

function fromB64(b64: string): Uint8Array {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

// ---------- thumbnail ----------

/** Render the design to a small PNG strip (the gallery card image). */
export function makeThumbnailB64(map: SeatMap, store: DesignStore): string {
  // Wider source than it displays at, so the gallery banner stays crisp (the
  // card shows the whole unrolled tifo at its true aspect via .card-thumb-img).
  const W = 800;
  const bw = map.bounds.maxX - map.bounds.minX;
  const bh = map.bounds.maxY - map.bounds.minY;
  const scale = W / bw;
  const H = Math.max(24, Math.round(bh * scale) + 4);
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#14171f';
  ctx.fillRect(0, 0, W, H);
  const colors = store.palette.map((hex, i) => (i === 0 ? '#262a33' : hex));
  for (let c = 0; c < colors.length; c++) {
    ctx.fillStyle = colors[c];
    for (let i = 0; i < map.count; i++) {
      if (store.cells[i] !== c) continue;
      const x = (map.xy[i * 2] - map.bounds.minX) * scale;
      const y = (map.xy[i * 2 + 1] - map.bounds.minY) * scale + 2;
      ctx.fillRect(x, y, Math.max(0.6, 3.2 * scale), Math.max(1, 8 * scale * 0.85));
    }
  }
  return canvas.toDataURL('image/png').split(',')[1];
}

// ---------- designs ----------

export interface SavedMeta {
  id: string;
  title: string;
  isPublic: boolean;
  updatedAt: string;
}

/** Create (no id) or overwrite (with id) a design, including a fresh thumbnail. */
export async function saveDesign(
  store: DesignStore,
  map: SeatMap,
  templateId: string,
  templateVersion: number,
  title: string,
  id: string | null,
): Promise<SavedMeta> {
  const cellsGzB64 = toB64(await gzip(store.cells));
  const thumbnailPngB64 = makeThumbnailB64(map, store);
  const payload = id
    ? { palette: store.palette, cellsGzB64, thumbnailPngB64 }
    : { title, templateId, templateVersion, palette: store.palette, cellsGzB64, thumbnailPngB64 };
  const res = await fetch(id ? `${API}/designs/${id}` : `${API}/designs`, {
    method: id ? 'PUT' : 'POST',
    headers: authHeaders(true),
    body: JSON.stringify(payload),
  });
  const meta = (await expectOk(res)) as SavedMeta;
  // Generate + store the branded 1200x630 social card so /t/:id previews richly.
  // Best-effort: never fail a save because the OG image couldn't be stored.
  try {
    if (meta.id) await uploadOgImage(meta.id, makeOgImageB64(map, store, title || meta.title));
  } catch {
    /* ignore */
  }
  return meta;
}

export async function setPublic(id: string, isPublic: boolean): Promise<SavedMeta> {
  const res = await fetch(`${API}/designs/${id}`, {
    method: 'PATCH',
    headers: authHeaders(true),
    body: JSON.stringify({ isPublic }),
  });
  return (await expectOk(res)) as SavedMeta;
}

/** Fetch a design (must be public or yours) and load it into the store. */
export async function loadDesign(
  store: DesignStore,
  id: string,
): Promise<{ title: string; isPublic: boolean; ownerIsMe: boolean; templateId: string; templateVersion: number }> {
  const data = (await expectOk(await fetch(`${API}/designs/${id}`, { headers: authHeaders(false) }))) as {
    title: string;
    palette: string[];
    cellsGzB64: string;
    isPublic: boolean;
    ownerId: string | null;
    templateId: string;
    templateVersion: number;
  };
  const cells = await gunzip(fromB64(data.cellsGzB64));
  store.setPalette(data.palette.slice(0, 256));
  store.loadCells(cells);
  let ownerIsMe = false;
  if (token) {
    const me = (await expectOk(await fetch(`${API}/me`, { headers: authHeaders(false) }))) as { id: string };
    ownerIsMe = me.id === data.ownerId;
  }
  return {
    title: data.title,
    isPublic: data.isPublic,
    ownerIsMe,
    templateId: data.templateId,
    templateVersion: data.templateVersion,
  };
}

/** Fetch a design's template id/version without loading cells (for share-link boot). */
export async function fetchDesignTemplate(id: string): Promise<{ templateId: string; templateVersion: number }> {
  const data = (await expectOk(await fetch(`${API}/designs/${id}`, { headers: authHeaders(false) }))) as {
    templateId: string;
    templateVersion: number;
  };
  return { templateId: data.templateId, templateVersion: data.templateVersion };
}

/** Canonical public share link for a design: https://host/t/:id (the dedicated
 * view page with rich previews). The old /d/:id editor-load link still works. */
export function shareUrl(id: string): string {
  return `${location.origin}/t/${id}`;
}

/** URL of a design's branded social card (falls back to the thumbnail server-side). */
export function ogImageUrl(id: string): string {
  return `${API}/designs/${id}/og.png`;
}

export interface PublicDesignMeta {
  title: string;
  ownerName: string | null;
  ownerIsMe: boolean;
  isPublic: boolean;
  templateId: string;
  templateVersion: number;
  createdAt: string;
  viewCount: number;
}

export interface ShareStats {
  views: number;
  shares: number;
  opens: number;
  byPlatform: Record<string, number>;
}

/** Load a design into the store AND return its public-page metadata. */
export async function loadPublicDesign(store: DesignStore, id: string): Promise<PublicDesignMeta> {
  const data = (await expectOk(await fetch(`${API}/designs/${id}`, { headers: authHeaders(false) }))) as {
    title: string;
    palette: string[];
    cellsGzB64: string;
    isPublic: boolean;
    ownerId: string | null;
    ownerName: string | null;
    templateId: string;
    templateVersion: number;
    createdAt: string;
    viewCount?: number;
  };
  const cells = await gunzip(fromB64(data.cellsGzB64));
  store.setPalette(data.palette.slice(0, 256));
  store.loadCells(cells);
  let ownerIsMe = false;
  if (token) {
    const me = (await expectOk(await fetch(`${API}/me`, { headers: authHeaders(false) }))) as { id: string };
    ownerIsMe = me.id === data.ownerId;
  }
  return {
    title: data.title,
    ownerName: data.ownerName ?? null,
    ownerIsMe,
    isPublic: data.isPublic,
    templateId: data.templateId,
    templateVersion: data.templateVersion,
    createdAt: data.createdAt,
    viewCount: data.viewCount ?? 0,
  };
}

/** Count a public view; returns the new total (0 on failure). */
export async function recordView(id: string): Promise<number> {
  try {
    const r = (await expectOk(await fetch(`${API}/designs/${id}/view`, { method: 'POST', headers: authHeaders(true), body: '{}' }))) as { views: number };
    return r.views ?? 0;
  } catch {
    return 0;
  }
}

/** Log a share button press (or a link open) for analytics. Best-effort. */
export function recordShare(id: string, platform: string, kind: 'share' | 'open' = 'share'): void {
  void fetch(`${API}/designs/${id}/share`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({ platform, kind }),
  }).catch(() => {});
}

/** Fetch share/view analytics for a design. */
export async function fetchShareStats(id: string): Promise<ShareStats> {
  return (await expectOk(await fetch(`${API}/designs/${id}/stats`, { headers: authHeaders(false) }))) as ShareStats;
}

/** Upload the branded OG card for a saved design (owner only). Best-effort. */
export async function uploadOgImage(id: string, ogPngB64: string): Promise<void> {
  await fetch(`${API}/designs/${id}/og-image`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({ ogPngB64 }),
  }).catch(() => {});
}

/**
 * Compose a branded 1200x630 social card: the unrolled tifo as a banner over a
 * dark field, with the title, creator and TifoMaker wordmark. Reuses the same
 * seat-drawing approach as makeThumbnailB64 — no new rendering pipeline.
 */
export function makeOgImageB64(map: SeatMap, store: DesignStore, title: string, ownerName?: string | null): string {
  const W = 1200;
  const H = 630;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;
  // Background.
  ctx.fillStyle = '#0a0c11';
  ctx.fillRect(0, 0, W, H);
  // Tifo banner: full unrolled bowl, fit to width with side margins, vertically
  // centered in the upper area.
  const margin = 64;
  const bw = map.bounds.maxX - map.bounds.minX;
  const bh = map.bounds.maxY - map.bounds.minY;
  const drawW = W - margin * 2;
  const scale = drawW / bw;
  const drawH = bh * scale;
  const offX = margin;
  const offY = 150 - drawH / 2 + 120; // sit the banner in the upper-middle
  const colors = store.palette.map((hex, i) => (i === 0 ? '#262a33' : hex));
  for (let c = 0; c < colors.length; c++) {
    ctx.fillStyle = colors[c];
    for (let i = 0; i < map.count; i++) {
      if (store.cells[i] !== c) continue;
      const x = offX + (map.xy[i * 2] - map.bounds.minX) * scale;
      const y = offY + (map.xy[i * 2 + 1] - map.bounds.minY) * scale;
      ctx.fillRect(x, y, Math.max(1, 3.2 * scale), Math.max(1, 8 * scale * 0.85));
    }
  }
  // Title + creator.
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = '#f2f1ec';
  ctx.font = '700 64px Inter, Arial, sans-serif';
  ctx.fillText(clip(ctx, title || 'Untitled tifo', W - margin * 2), margin, H - 150);
  if (ownerName) {
    ctx.fillStyle = '#9aa3b2';
    ctx.font = '500 34px Inter, Arial, sans-serif';
    ctx.fillText(`by @${ownerName}`, margin, H - 100);
  }
  // Wordmark.
  ctx.font = '800 34px Inter, Arial, sans-serif';
  ctx.fillStyle = '#5b8cff';
  ctx.fillText('TIFO', margin, H - 48);
  const tw = ctx.measureText('TIFO').width;
  ctx.fillStyle = '#f2f1ec';
  ctx.fillText('MAKER', margin + tw, H - 48);
  return canvas.toDataURL('image/png').split(',')[1];
}

/** Truncate text with an ellipsis to fit `maxW` px in the current ctx font. */
function clip(ctx: CanvasRenderingContext2D, text: string, maxW: number): string {
  if (ctx.measureText(text).width <= maxW) return text;
  let t = text;
  while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1);
  return t + '…';
}

export interface GalleryItem {
  id: string;
  title: string;
  ownerId: string | null;
  ownerName: string;
  hasThumbnail: boolean;
  likeScore: number;
  myVote: number;
  updatedAt: string;
  isTemplate: boolean;
  tags: string[];
  hasPhoto: boolean;
  description?: string | null;
  allowRemix?: boolean;
  remixedFrom?: string | null;
  remixedFromName?: string | null;
  remixedFromTitle?: string | null;
}

export type GallerySort = 'recent' | 'likes';

export async function listGallery(
  opts: { sort?: GallerySort; search?: string; tags?: string[]; templatesOnly?: boolean } = {},
): Promise<GalleryItem[]> {
  const params = new URLSearchParams();
  if (opts.sort) params.set('sort', opts.sort);
  if (opts.search) params.set('search', opts.search);
  if (opts.tags && opts.tags.length) params.set('tags', opts.tags.join(','));
  if (opts.templatesOnly) params.set('templates', '1');
  const qs = params.toString();
  return (await expectOk(await fetch(`${API}/gallery${qs ? `?${qs}` : ''}`, { headers: authHeaders(false) }))) as GalleryItem[];
}

/** Most-used tags across public designs (for filter chips). */
export async function listPopularTags(): Promise<{ slug: string; kind: string; count: number }[]> {
  return (await expectOk(await fetch(`${API}/tags`))) as { slug: string; kind: string; count: number }[];
}

/** Replace a design's tags (owner only). */
export async function setDesignTags(id: string, tags: string[]): Promise<string[]> {
  const res = (await expectOk(
    await fetch(`${API}/designs/${id}/tags`, { method: 'PUT', headers: authHeaders(true), body: JSON.stringify({ tags }) }),
  )) as { tags: string[] };
  return res.tags;
}

/** Flag/unflag a design as a community template (owner only). */
export async function setDesignTemplate(id: string, isTemplate: boolean): Promise<boolean> {
  const res = (await expectOk(
    await fetch(`${API}/designs/${id}/template`, {
      method: 'PUT',
      headers: authHeaders(true),
      body: JSON.stringify({ isTemplate }),
    }),
  )) as { isTemplate: boolean };
  return res.isTemplate;
}

/** Report a public design for moderation. */
/** Report a public design for moderation. */
export async function reportDesign(id: string, reason: string): Promise<void> {
  await expectOk(
    await fetch(`${API}/report`, {
      method: 'POST',
      headers: authHeaders(false),
      body: JSON.stringify({ targetType: 'design', targetId: id, reason }),
    }),
  );
}

export interface PhotoMeta {
  id: string;
  designId: string;
  width: number;
  height: number;
  caption: string | null;
  isVerified: boolean;
  createdAt: string;
}

/** A design's real match-day photos (newest first). */
export async function listPhotos(designId: string): Promise<PhotoMeta[]> {
  return (await expectOk(await fetch(`${API}/designs/${designId}/photos`))) as PhotoMeta[];
}

export const photoUrl = (photoId: string): string => `${API}/photos/${photoId}`;

/**
 * Resize an image file to fit within maxDim (longest edge) as a JPEG, keeping
 * uploads lean, then upload it as a match-day photo. Returns the new photo id.
 */
export async function uploadPhoto(
  designId: string,
  file: File,
  caption: string,
  maxDim = 1600,
): Promise<string> {
  const { dataUrl, width, height } = await resizeToJpeg(file, maxDim);
  const imageB64 = dataUrl.split(',')[1];
  const res = (await expectOk(
    await fetch(`${API}/designs/${designId}/photos`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ imageB64, width, height, caption }),
    }),
  )) as { photoId: string };
  return res.photoId;
}

/** Delete a photo (owner only). */
export async function deletePhoto(photoId: string): Promise<void> {
  await expectOk(await fetch(`${API}/photos/${photoId}`, { method: 'DELETE', headers: authHeaders(true) }));
}

/** Downscale an image to fit maxDim and re-encode as JPEG. Browser-side. */
async function resizeToJpeg(file: File, maxDim: number): Promise<{ dataUrl: string; width: number; height: number }> {
  const bitmap = await createImageBitmap(file);
  let { width, height } = bitmap;
  const scale = Math.min(1, maxDim / Math.max(width, height));
  width = Math.round(width * scale);
  height = Math.round(height * scale);
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  return { dataUrl: canvas.toDataURL('image/jpeg', 0.85), width, height };
}

/** Like (1), dislike (-1), or clear (0) a design. Returns the new score + vote. */
export async function voteDesign(id: string, value: 1 | -1 | 0): Promise<{ likeScore: number; myVote: number }> {
  return (await expectOk(
    await fetch(`${API}/designs/${id}/vote`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ value }),
    }),
  )) as { likeScore: number; myVote: number };
}

export interface ProfileData {
  id: string;
  username: string;
  created: GalleryItem[];
  liked: GalleryItem[];
  handle?: string | null;
  followerCount?: number;
  followingCount?: number;
  designCount?: number;
  isFollowing?: boolean;
}

export async function fetchProfile(userId: string): Promise<ProfileData> {
  return (await expectOk(await fetch(`${API}/users/${userId}/profile`, { headers: authHeaders(false) }))) as ProfileData;
}

/** The signed-in user's id + name, or null. */
export async function fetchMe(): Promise<{
  id: string;
  username: string;
  email: string | null;
  emailVerified: boolean;
  isAdmin: boolean;
} | null> {
  if (!token) return null;
  try {
    return (await expectOk(await fetch(`${API}/me`, { headers: authHeaders(false) }))) as {
      id: string;
      username: string;
      email: string | null;
      emailVerified: boolean;
      isAdmin: boolean;
    };
  } catch {
    return null;
  }
}

// ---- moderation / trust review (admin only) ----
export interface ReportItem {
  id: string;
  targetType: string;
  targetId: string;
  reason: string;
  status: string;
  createdAt: string;
  targetTitle: string | null;
  targetOwner: string | null;
  targetIsPublic: boolean | null;
  targetHasThumbnail: boolean;
}
export interface PhotoReviewItem {
  id: string;
  designId: string;
  designTitle: string | null;
  caption: string | null;
  createdAt: string;
}

export async function listReports(status = 'open'): Promise<ReportItem[]> {
  return (await expectOk(await fetch(`${API}/admin/reports?status=${status}`, { headers: authHeaders(true) }))) as ReportItem[];
}
export async function dismissReport(id: string): Promise<void> {
  await expectOk(await fetch(`${API}/admin/reports/${id}/dismiss`, { method: 'POST', headers: authHeaders(true) }));
}
export async function takedownDesign(id: string): Promise<void> {
  await expectOk(await fetch(`${API}/admin/designs/${id}/takedown`, { method: 'POST', headers: authHeaders(true) }));
}
export async function listUnverifiedPhotos(): Promise<PhotoReviewItem[]> {
  return (await expectOk(await fetch(`${API}/admin/photos/unverified`, { headers: authHeaders(true) }))) as PhotoReviewItem[];
}
export async function verifyPhoto(photoId: string, verified: boolean): Promise<void> {
  await expectOk(
    await fetch(`${API}/admin/photos/${photoId}/verify`, {
      method: 'POST',
      headers: authHeaders(true),
      body: JSON.stringify({ verified }),
    }),
  );
}
export async function adminDeletePhoto(photoId: string): Promise<void> {
  await expectOk(await fetch(`${API}/admin/photos/${photoId}`, { method: 'DELETE', headers: authHeaders(true) }));
}

export const thumbnailUrl = (id: string): string => `${API}/designs/${id}/thumbnail.png`;

/** Request a server-rendered distribution PDF for the current (unsaved) design. */
export async function exportDistributionPdf(
  store: DesignStore,
  map: SeatMap,
  opts: { title: string; cardsPerBag: number; colorNames?: string[] },
): Promise<Blob> {
  const cellsGzB64 = toB64(await gzip(store.cells));
  const res = await fetch(`${API}/export/pdf`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({
      title: opts.title,
      templateId: map.templateRef.id,
      templateVersion: map.templateRef.version,
      palette: store.palette,
      cellsGzB64,
      cardsPerBag: opts.cardsPerBag,
      colorNames: opts.colorNames,
    }),
  });
  if (!res.ok) {
    const err = (await res.json().catch(() => ({ error: res.statusText }))) as { error?: string };
    throw new Error(err.error ?? `export failed (${res.status})`);
  }
  return res.blob();
}

// ============ social client ============

export interface PublicProfile {
  id: string;
  username: string;
  handle: string | null;
  followerCount: number;
  followingCount: number;
  designCount: number;
  isFollowing?: boolean;
}

export interface CommentItem {
  id: string;
  designId: string;
  authorId: string;
  authorName: string;
  parentId: string | null;
  body: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  kind: string;
  actorId: string | null;
  actorName: string | null;
  designId: string | null;
  designTitle: string | null;
  commentId: string | null;
  readAt: string | null;
  createdAt: string;
}

/** Set a design's creator explanation + remix permission (owner only). */
export async function setPublishMeta(id: string, description: string | null, allowRemix: boolean): Promise<void> {
  const res = await fetch(`${API}/designs/${id}/publish-meta`, {
    method: 'PUT',
    headers: authHeaders(true),
    body: JSON.stringify({ description, allowRemix }),
  });
  if (!res.ok) throw new Error(`could not save publish details (${res.status})`);
}

/** Remix a public design into the caller's account; returns the new design id. */
export async function remixDesign(id: string, title?: string): Promise<{ id: string }> {
  const res = await fetch(`${API}/designs/${id}/remix`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({ title }),
  });
  if (!res.ok) {
    const e = (await res.json().catch(() => ({ error: res.statusText }))) as { error?: string };
    throw new Error(e.error ?? `remix failed (${res.status})`);
  }
  return res.json() as Promise<{ id: string }>;
}

export async function followUser(userId: string): Promise<void> {
  const res = await fetch(`${API}/users/${userId}/follow`, { method: 'POST', headers: authHeaders(false) });
  if (!res.ok) throw new Error(`follow failed (${res.status})`);
}
export async function unfollowUser(userId: string): Promise<void> {
  const res = await fetch(`${API}/users/${userId}/follow`, { method: 'DELETE', headers: authHeaders(false) });
  if (!res.ok) throw new Error(`unfollow failed (${res.status})`);
}

export async function searchUsers(q: string): Promise<PublicProfile[]> {
  const res = await fetch(`${API}/users/search?q=${encodeURIComponent(q)}`);
  if (!res.ok) return [];
  return res.json() as Promise<PublicProfile[]>;
}

export async function listComments(designId: string): Promise<CommentItem[]> {
  const res = await fetch(`${API}/designs/${designId}/comments`);
  if (!res.ok) return [];
  return res.json() as Promise<CommentItem[]>;
}
export async function addComment(designId: string, body: string, parentId: string | null): Promise<CommentItem> {
  const res = await fetch(`${API}/designs/${designId}/comments`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({ body, parentId }),
  });
  if (!res.ok) {
    const e = (await res.json().catch(() => ({ error: res.statusText }))) as { error?: string };
    throw new Error(e.error ?? `comment failed (${res.status})`);
  }
  return res.json() as Promise<CommentItem>;
}
export async function deleteComment(commentId: string): Promise<void> {
  const res = await fetch(`${API}/comments/${commentId}`, { method: 'DELETE', headers: authHeaders(false) });
  if (!res.ok) throw new Error(`delete failed (${res.status})`);
}

export async function listNotifications(): Promise<{ unread: number; items: NotificationItem[] }> {
  const res = await fetch(`${API}/notifications`, { headers: authHeaders(false) });
  if (!res.ok) return { unread: 0, items: [] };
  return res.json() as Promise<{ unread: number; items: NotificationItem[] }>;
}
export async function markNotificationsRead(id?: string): Promise<void> {
  await fetch(`${API}/notifications/read`, {
    method: 'POST',
    headers: authHeaders(true),
    body: JSON.stringify({ id }),
  }).catch(() => {});
}

// ============ B2B leads ============

export interface LeadInput {
  name: string;
  email: string;
  organization?: string;
  orgType?: string;
  message?: string;
}

/** Submit a B2B lead from the For Clubs page. */
export async function submitLead(lead: LeadInput): Promise<{ ok: boolean; id?: string }> {
  const res = await fetch(`${API}/leads`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(lead),
  });
  if (!res.ok) {
    const e = (await res.json().catch(() => ({ error: res.statusText }))) as { error?: string };
    throw new Error(e.error ?? `submission failed (${res.status})`);
  }
  return res.json() as Promise<{ ok: boolean; id?: string }>;
}

// ---------- AI Tifo Designer ----------

const AI_UNLOCK_KEY = 'tifo_ai_unlock_v1';

/** The admin AI-unlock token (opaque, server-signed). Persists across sessions. */
export function aiUnlockToken(): string | null {
  try {
    return localStorage.getItem(AI_UNLOCK_KEY);
  } catch {
    return null;
  }
}
function setAiUnlockToken(t: string | null): void {
  try {
    if (t) localStorage.setItem(AI_UNLOCK_KEY, t);
    else localStorage.removeItem(AI_UNLOCK_KEY);
  } catch {
    /* storage unavailable */
  }
}

/** Auth headers, plus the AI admin-unlock token when present. */
function aiHeaders(json: boolean): Record<string, string> {
  const h = authHeaders(json);
  const tok = aiUnlockToken();
  if (tok) h['x-ai-unlock'] = tok;
  return h;
}

/** Exchange the admin password for a signed unlock token (stored locally). */
export async function unlockAi(password: string): Promise<boolean> {
  const res = await fetch(`${API}/ai/unlock`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ password }),
  });
  if (!res.ok) return false;
  const data = (await res.json().catch(() => null)) as { token?: string } | null;
  if (!data?.token) return false;
  setAiUnlockToken(data.token);
  return true;
}

export interface AiQuota {
  used: number;
  limit: number;
  remaining: number;
  provider?: string;
  /** True when the caller has admin access. */
  admin?: boolean;
  /** True when the caller has unlimited use (admin or paid). */
  unlimited?: boolean;
  /** Seconds until the hourly quota resets (for the "resets in …" UI). */
  resetInSec?: number;
}

export interface AiGenerateResult {
  spec: TifoSpec;
  quota: AiQuota;
  source: 'model' | 'offline' | 'quick';
  /** Server-side diagnostics (image-gen failures) for the UI. */
  notes?: string[];
}

/**
 * Returned by generate when premium can't deliver right now (busy, or hourly cap
 * reached): the client offers a choice — use the free Quick Designer, or wait + retry.
 */
export interface AiChoice {
  needsChoice: true;
  reason: 'busy' | 'quota' | 'premium_off';
  retryAfterSec: number;
  quota: AiQuota;
}

/** Error thrown by the AI calls; `status` 403 with `locked` = admin-only. */
export interface AiError extends Error {
  status?: number;
  quota?: AiQuota;
  locked?: boolean;
  /** Why access was denied: 'signin', 'verify' (email), or 'quota' (limit reached). */
  reason?: 'signin' | 'verify' | 'quota';
}

/**
 * Ask the server to design a tifo from a prompt. Returns a validated TifoSpec
 * (the client compiles it to seats). On failure throws an AiError whose `status`
 * distinguishes 403 (locked, admin-only), 401 (sign in), 402 (out of credits).
 */
export async function generateAiTifo(
  prompt: string,
  opts: { mode?: 'super'; stadium?: string; engine?: 'offline' } = {},
): Promise<AiGenerateResult | AiChoice> {
  const res = await fetch(`${API}/ai/generate`, {
    method: 'POST',
    headers: aiHeaders(true),
    body: JSON.stringify({
      prompt,
      ...(opts.mode ? { mode: opts.mode } : {}),
      ...(opts.stadium ? { stadium: opts.stadium } : {}),
      ...(opts.engine ? { engine: opts.engine } : {}),
    }),
  });
  const data = (await res.json().catch(() => null)) as
    | ({ needsChoice?: boolean; reason?: string; retryAfterSec?: number; quota?: AiQuota; error?: string; locked?: boolean } & Partial<AiGenerateResult>)
    | null;
  if (!res.ok) {
    const err = new Error(data?.error ?? `generation failed (${res.status})`) as AiError;
    err.status = res.status;
    err.quota = data?.quota;
    err.locked = data?.locked;
    err.reason = data?.reason as AiError['reason'];
    throw err;
  }
  if (data?.needsChoice) {
    return {
      needsChoice: true,
      reason: (data.reason ?? 'busy') as AiChoice['reason'],
      retryAfterSec: data.retryAfterSec ?? 90,
      quota: data.quota as AiQuota,
    };
  }
  return data as AiGenerateResult;
}

export interface AiCritiqueResult {
  spec: TifoSpec;
  source: 'model' | 'original';
  notes?: string[];
}

/** Phase 4b: send the current design + a low-res render to the vision critic; get an improved spec back. */
export async function critiqueAiTifo(spec: TifoSpec, image?: string, stadium?: string): Promise<AiCritiqueResult> {
  const res = await fetch(`${API}/ai/critique`, {
    method: 'POST',
    headers: aiHeaders(true),
    body: JSON.stringify({ spec, ...(image ? { image } : {}), ...(stadium ? { stadium } : {}) }),
  });
  const data = (await res.json().catch(() => null)) as (AiCritiqueResult & { error?: string }) | null;
  if (!res.ok) {
    const err = new Error(data?.error ?? `critique failed (${res.status})`) as AiError;
    err.status = res.status;
    throw err;
  }
  return data as AiCritiqueResult;
}

/** Read AI access/quota. Throws an AiError (status 403, locked) when admin-only. */
export async function fetchAiQuota(): Promise<AiQuota> {
  const res = await fetch(`${API}/ai/quota`, { headers: aiHeaders(false) });
  const data = (await res.json().catch(() => null)) as (AiQuota & { error?: string; locked?: boolean; reason?: AiError['reason'] }) | null;
  if (!res.ok) {
    const err = new Error(data?.error ?? `request failed (${res.status})`) as AiError;
    err.status = res.status;
    err.locked = data?.locked;
    err.reason = data?.reason;
    throw err;
  }
  return data as AiQuota;
}
